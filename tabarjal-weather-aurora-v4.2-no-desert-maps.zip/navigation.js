
/* Aurora 4.0 navigation enhancements */
(function(){
 const menu=document.getElementById('serviceMenu');
 if(!menu)return;
 menu.querySelectorAll('a').forEach(link=>link.addEventListener('click',()=>{menu.open=false}));
 document.addEventListener('click',event=>{if(menu.open&&!menu.contains(event.target))menu.open=false});
 document.addEventListener('keydown',event=>{if(event.key==='Escape'&&menu.open){menu.open=false;menu.querySelector('summary').focus()}});
})();
